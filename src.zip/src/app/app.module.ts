import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LandinghomeComponent } from './home/landinghome/landinghome.component';
import { FooterComponent } from './footer/footer.component';
import { VaccinationcountComponent } from './home/vaccinationcount/vaccinationcount.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LandinghomeComponent,
    FooterComponent,
    VaccinationcountComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
