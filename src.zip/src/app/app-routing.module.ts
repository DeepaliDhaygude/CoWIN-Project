import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LandinghomeComponent } from './home/landinghome/landinghome.component';
import { VaccinationcountComponent } from './home/vaccinationcount/vaccinationcount.component';

const routes: Routes = [
  {path:'header', component:HeaderComponent},
  {path:'footer', component:FooterComponent},
  {path:'landinghome', component:LandinghomeComponent},
  {path:'vaccinationcount', component:VaccinationcountComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
