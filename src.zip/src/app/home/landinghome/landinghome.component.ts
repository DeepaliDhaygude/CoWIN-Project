import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landinghome',
  templateUrl: './landinghome.component.html',
  styleUrls: ['./landinghome.component.css']
})
export class LandinghomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
