import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LandinghomeComponent } from './landinghome/landinghome.component';
import { VaccinationcountComponent } from './vaccinationcount/vaccinationcount.component';



@NgModule({
  declarations: [
    LandinghomeComponent,
    VaccinationcountComponent
  ],
  imports: [
    CommonModule
  ]
})
export class HomeModule { }
