import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vaccinationcount',
  templateUrl: './vaccinationcount.component.html',
  styleUrls: ['./vaccinationcount.component.css']
})
export class VaccinationcountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
